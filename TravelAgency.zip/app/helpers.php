<?php

function customAsset($path) {
    return asset($path);
}