<?php

namespace App\Http\Controllers;

use App\Models\onlineAssessmentJobsModel;
use App\Http\Requests\StoreonlineAssessmentJobsModelRequest;
use App\Http\Requests\UpdateonlineAssessmentJobsModelRequest;

class OnlineAssessmentJobsModelController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreonlineAssessmentJobsModelRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(onlineAssessmentJobsModel $onlineAssessmentJobsModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(onlineAssessmentJobsModel $onlineAssessmentJobsModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateonlineAssessmentJobsModelRequest $request, onlineAssessmentJobsModel $onlineAssessmentJobsModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(onlineAssessmentJobsModel $onlineAssessmentJobsModel)
    {
        //
    }
}
