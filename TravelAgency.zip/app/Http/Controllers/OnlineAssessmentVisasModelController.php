<?php

namespace App\Http\Controllers;

use App\Models\onlineAssessmentVisasModel;
use App\Http\Requests\StoreonlineAssessmentVisasModelRequest;
use App\Http\Requests\UpdateonlineAssessmentVisasModelRequest;

class OnlineAssessmentVisasModelController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreonlineAssessmentVisasModelRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(onlineAssessmentVisasModel $onlineAssessmentVisasModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(onlineAssessmentVisasModel $onlineAssessmentVisasModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateonlineAssessmentVisasModelRequest $request, onlineAssessmentVisasModel $onlineAssessmentVisasModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(onlineAssessmentVisasModel $onlineAssessmentVisasModel)
    {
        //
    }
}
