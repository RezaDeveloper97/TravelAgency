 
<?php $__env->startSection('title', 'عنوان'); ?>
 

<?php $__env->startPrepend('endOfhead'); ?>
    
<?php $__env->stopPrepend(); ?>

<?php $__env->startSection('content'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startPrepend('endOfbody'); ?>
    
<?php $__env->stopPrepend(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TravelAgency\resources\views/front/blank.blade.php ENDPATH**/ ?>