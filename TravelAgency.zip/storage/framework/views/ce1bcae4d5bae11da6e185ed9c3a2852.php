 
<?php $__env->startSection('title', 'داشبورد'); ?>
 

<?php $__env->startPrepend('endOfhead'); ?>
    
<?php $__env->stopPrepend(); ?>

<?php $__env->startSection('content'); ?>
<main>
    <header class="page-header page-header-dark bg-gradient-custom-to-custom pb-10 is-rtl">
        <div class="container-xl px-4">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <i class="ms-1 me-1 bx bx-filter"></i>
                            لیست فرم ارزیابی
                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="container-xl px-4 mt-n10 is-rtl">
        <div class="card mb-4">
            <div class="card-header">جدول داده ها</div>
            <div class="card-body">


                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>نام و نام خانوادگی</th>
                            <th>تلفن تماس (whatsapp)</th>
                            <th>آدرس ايميل</th>
                            <th>تاریخ ارسال فرم</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>نام و نام خانوادگی</th>
                            <th>تلفن تماس (whatsapp)</th>
                            <th>آدرس ايميل</th>
                            <th>تاریخ ارسال فرم</th>
                            <th>عملیات</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                            $onlineAssessmentModel = \App\Models\onlineAssessmentModel::all();
                        ?>
                        <?php $__currentLoopData = $onlineAssessmentModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->fnamelname); ?></td>
                                <td><?php echo e($row->whatsapp); ?></td>
                                <td><?php echo e($row['active-email']); ?></td>
                                <td><?php echo e($row->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('forms.assessment-view', $row->id)); ?>" class="btn btn-datatable btn-icon btn-transparent-dark me-2"><i class="bx bx-show"></i></a>
                                    <button class="btn btn-datatable btn-icon btn-transparent-dark"><i class="bx bx-trash"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<footer class="footer-admin mt-auto footer-light is-rtl">
    <div class="container-xl px-4">
        <div class="row">
            <div class="col-md-6 small">طراحی شده با ❤️ ارائه شده در وب‌سایت راست‌چین</div>
            <div class="col-md-6 text-md-end small">
                <a href="#!">قوانین و مقررات</a>
                ·
                <a href="#!">لایسنس ها</a>
            </div>
        </div>
    </div>
</footer>
<?php $__env->stopSection(); ?>


<?php $__env->startPrepend('endOfbody'); ?>
<script src="<?php echo e(customAsset('assets/js/simple-datatables%40latest.js')); ?>"></script>
<script src="<?php echo e(customAsset('assets/js/simple-datatables%40demo.js')); ?>"></script>
<?php $__env->stopPrepend(); ?>
<?php echo $__env->make('layouts.panel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TravelAgency\resources\views/panel/assessment.blade.php ENDPATH**/ ?>