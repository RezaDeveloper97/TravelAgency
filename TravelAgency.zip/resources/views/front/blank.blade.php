@extends('layouts.front')
 
@section('title', 'Theodoraworld')
 
{{-- head modules --}}
@prepend('endOfhead')
    
@endprepend

@section('content')
    
@endsection

{{-- body modules --}}
@prepend('endOfbody')
    
@endprepend